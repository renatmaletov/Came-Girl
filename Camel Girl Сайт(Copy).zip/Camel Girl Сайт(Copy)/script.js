const canvas = document.createElement('canvas');
canvas.id = 'sparks-canvas';
document.body.appendChild(canvas);

const ctx = canvas.getContext('2d');
canvas.style.position = 'fixed';
canvas.style.top = '0';
canvas.style.left = '0';
canvas.style.zIndex = '-1';
canvas.style.pointerEvents = 'none';
canvas.style.width = '100%';
canvas.style.height = '100%';

let sparks = [];

function resizeCanvas() {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
}
resizeCanvas();
window.addEventListener('resize', resizeCanvas);

function createSpark() {
  return {
    x: Math.random() * canvas.width,
    y: Math.random() * canvas.height,
    radius: Math.random() * 2 + 1,
    speedY: Math.random() * 0.5 + 0.2,
    alpha: Math.random() * 0.5 + 0.3
  };
}

for (let i = 0; i < 100; i++) {
  sparks.push(createSpark());
}

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  for (let spark of sparks) {
    ctx.beginPath();
    ctx.arc(spark.x, spark.y, spark.radius, 0, Math.PI * 2);
    ctx.fillStyle = `rgba(255, 100, 0, ${spark.alpha})`;
    ctx.fill();
    spark.y += spark.speedY;
    if (spark.y > canvas.height) {
      spark.y = 0;
      spark.x = Math.random() * canvas.width;
    }
  }
  requestAnimationFrame(draw);
}

draw();